#ifndef PERM_POTION_H
#define PERM_POTION_H

#include "potion.h"

class PermPotion : public Potion {
    public:
        PermPotion(int value);
        virtual ~PermPotion();
};

#endif
