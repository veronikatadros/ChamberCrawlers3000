#include "headers/items/goldHoard.h"

GoldHoard::GoldHoard() : Protected{'G', GOLD_HOARD} {}

GoldHoard::~GoldHoard() {}
