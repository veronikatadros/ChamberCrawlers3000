#include "headers/enemyTypes/goblin.h"

Goblin::Goblin() : Enemy{'N', 5, 70, 5, 10} {}

Goblin::~Goblin() {}
