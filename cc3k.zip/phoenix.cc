#include "headers/enemyTypes/phoenix.h"

Phoenix::Phoenix() : Enemy{'X', 2, 50, 35, 20} {}

Phoenix::~Phoenix() {}
