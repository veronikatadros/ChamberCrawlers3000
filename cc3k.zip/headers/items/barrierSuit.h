#ifndef BARRIER_SUIT_H
#define BARRIER_SUIT_H

#include "protected.h"

class BarrierSuit : public Protected {
    public:
        BarrierSuit();
        virtual ~BarrierSuit();
};

#endif
