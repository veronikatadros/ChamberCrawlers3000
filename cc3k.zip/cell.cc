#include "headers/cell.h"

Cell::Cell(CellType c, Entity* e) : cellType(c), occupant(e) {}
