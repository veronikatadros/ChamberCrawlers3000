#include "headers/items/compass.h"

Compass::Compass() : Item{'C', COMPASS} {}

Compass::~Compass() {}
