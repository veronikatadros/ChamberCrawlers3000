#ifndef GOBLIN_H
#define GOBLIN_H

#include "../enemy.h"

class Goblin : public Enemy {
    public:
        Goblin();
        virtual ~Goblin();
};

#endif
