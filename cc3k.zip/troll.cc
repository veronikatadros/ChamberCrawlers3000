#include "headers/enemyTypes/troll.h"

Troll::Troll() : Enemy{'T', 2, 120, 25, 15} {}

Troll::~Troll() {}
