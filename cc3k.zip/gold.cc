#include "headers/items/gold.h"

Gold::Gold(float value) : Item{'G', GOLD}, value{value} {}

Gold::~Gold() {}
