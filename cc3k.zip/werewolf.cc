#include "headers/enemyTypes/werewolf.h"

Werewolf::Werewolf() : Enemy{'W', 3, 120, 30, 5} {}

Werewolf::~Werewolf() {}
