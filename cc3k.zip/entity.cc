#include "headers/entity.h"

Entity::Entity(EntityType eType) : eType{eType} {}

Entity::~Entity() {}
