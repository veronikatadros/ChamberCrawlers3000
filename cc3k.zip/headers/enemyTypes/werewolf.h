#ifndef WEREWOLF_H
#define WEREWOLF_H

#include "../enemy.h"

class Werewolf : public Enemy {
    public:
        Werewolf();
        virtual ~Werewolf();
};

#endif
