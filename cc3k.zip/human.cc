#include "headers/playerRaces/human.h"

Human::Human() : Player{140, 20, 20, "Human"} {}

Human::~Human() {}
