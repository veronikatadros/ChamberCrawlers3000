#include "headers/items/permPotion.h"

PermPotion::PermPotion(int value) : Potion{value, "HP"} {}

PermPotion::~PermPotion() {}
